<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ViewAvoirChargeFixe extends Model
{
    use HasFactory;
    public $table = "view_avoir_charge_fixe";
}
