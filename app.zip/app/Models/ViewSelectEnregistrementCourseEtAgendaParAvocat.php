<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ViewSelectEnregistrementCourseEtAgendaParAvocat extends Model
{
    use HasFactory;
    public $table = "view_enregistrement_course_agenda_byavocat";
}
