<?php

namespace App\Http\Controllers\comptabiliteGenerale;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ControllerListerComptabiliteGenereles extends Controller
{
    //
}
