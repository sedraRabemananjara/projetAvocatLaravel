<?php

namespace App\Http\Controllers\etat;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Etat;

class ControllerInsertEtat extends Controller
{
    public function insert(Request $request)
    {
        $Etat = new Etat();
        $Etat->idEnregistrement = $request->input('idEnregistrement');

        $Etat->save();
        //return view("controlpanel.products");
        //$employe=new Employe;
        //$employe-> nom = $req->input('nom');;
        //$employe-> is_complete =0;
        //$employe->save();
        //return view('pageListerEtat',['listeEtats'=> Etat::all()]);
    }
}
