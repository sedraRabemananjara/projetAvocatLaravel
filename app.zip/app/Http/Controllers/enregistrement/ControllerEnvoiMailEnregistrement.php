<?php

namespace App\Http\Controllers\enregistrement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ControllerEnvoiMailEnregistrement extends Controller
{
    public static function envoyerMail($idEnregistrement)
    {
    }
}
