<?php

namespace App\Http\Controllers\enregistrement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ControllerSupprimerEnregistrement extends Controller
{
    //
}
